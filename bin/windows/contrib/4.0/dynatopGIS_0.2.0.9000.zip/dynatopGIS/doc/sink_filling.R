## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
                    collapse = TRUE,
                    comment = "#>"
                  )

## ----echo=FALSE---------------------------------------------------------------
## devtools::load_all("/home/paul/Documents/Software/dynamic_topmodel/dynatopGIS")
library("dynatopGIS")
library("raster")

## ---- data--------------------------------------------------------------------
M <- matrix(1:100,10,10)
fake <- raster::raster(M,
                       crs="+init=epsg:27700") # UK OS projection

## ---- example1----------------------------------------------------------------
ex1_dem <- fake
ex1_dem[c(23:26,33:36,44:45)] <- NA
ex1_chn <- fake; ex1_chn[] <- NA
ex1_chn[1,1] <- 1


ex1 <- dynatopGIS$new(ex1_dem)
ex1$add_layer(ex1_chn,"channel_id",FALSE)
ex1$sink_fill()
ex1$plot_layer("dem",FALSE)
ex1$plot_layer("filled_dem",FALSE)

## ---- example2----------------------------------------------------------------
ex2_dem <- fake
ex2_dem[c(23:26,33:36,44:45)] <- NA
ex2_chn <- fake; ex2_chn[] <- NA
ex2_chn[1,1] <- 1

ex2 <-  dynatopGIS$new(ex1_dem)
ex2$add_layer(ex2_chn,"channel_id",FALSE)
ex2$sink_fill()
ex2$plot_layer("dem",add=FALSE)
ex2$plot_layer("filled_dem",add=FALSE)

