## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----sim1s, echo=FALSE, fig.cap="Evolution of states with constant lateral flow to saturated zone eqivilent to potential maximum", out.width = '80%'----
##knitr::include_graphics("Fig_states_IR_1.png")

## ----sim1f, echo=FALSE, fig.cap="Evolution of fluxes with constant lateral flow to saturated zone eqivilent to potential maximum", out.width = '80%'----
##knitr::include_graphics("Fig_fluxes_IR_1.png")

## ----sim2s, echo=FALSE, fig.cap="Evolution of states with constant lateral flow to the surface zone eqivilent to potential maximum lateral saturated flux", out.width = '80%'----
##knitr::include_graphics("Fig_states_IR_2.png")

## ----sim2f, echo=FALSE, fig.cap="Evolution of fluxes with constant lateral flow to the surface zone eqivilent to potential maximum lateral saturated flux", out.width = '80%'----
##knitr::include_graphics("Fig_fluxes_IR_2.png")

## ----sim3s, echo=FALSE, fig.cap="Evolution of states for Simulation 3", out.width = '80%'----
##knitr::include_graphics("Fig_states_IR_3.png")

## ----sim3f, echo=FALSE, fig.cap="Evolution of fluxes for Simulation 3", out.width = '80%'----
##knitr::include_graphics("Fig_fluxes_IR_3.png")

