## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- setup-------------------------------------------------------------------
library(dynatop)
data("Swindale")

## ----data_loaded--------------------------------------------------------------
names(Swindale)

## ----sep----------------------------------------------------------------------
swindale_model <- Swindale$model
swindale_obs <- Swindale$obs

## ----model_parts--------------------------------------------------------------
names(swindale_model)

## ---- obs---------------------------------------------------------------------
head(swindale_obs)

## ---- set_obs_names-----------------------------------------------------------
swindale_model$hillslope[,'precip'] <- swindale_model$channel[,'precip'] <- "Rainfall"
swindale_model$hillslope[,'pet'] <- swindale_model$channel[,'pet'] <- "PET"

## ---- default_param-----------------------------------------------------------
print(swindale_model$param)

## ---- hru_param---------------------------------------------------------------
## unsaturated zone time constant
head( swindale_model$hillslope[,c('id','t_d')])

## ---- change_param------------------------------------------------------------
swindale_model$param <- c(r_sfmax_default=Inf,
                 m_default=0.0063,
                 ln_t0_default=7.46,
                 s_rz0_default=0.98,
                 s_rzmax_default=0.1,
                 v_ch_default=0.8,
                 t_d_default=8*60*60,
                 t_sf_default=3.6e+05
                 )

## ----create_object------------------------------------------------------------
ctch_mdl <- dynatop$new(swindale_model)

## ----add_data-----------------------------------------------------------------
ctch_mdl$add_data(swindale_obs)

## ----initialise---------------------------------------------------------------
ctch_mdl$initialise(1e-6)$plot_state("l_sz")

## ----sim1---------------------------------------------------------------------
sim1 <- ctch_mdl$sim()$get_gauge_flow()

## ----new_states---------------------------------------------------------------
ctch_mdl$plot_state("l_sz")

## ----sim2---------------------------------------------------------------------
sim2 <- ctch_mdl$sim()$get_gauge_flow()
out <- merge( merge(swindale_obs,sim1),sim2)
names(out) <- c(names(swindale_obs),'sim_1','sim_2')
plot(out[,c('Flow','sim_1','sim_2')])


## ----mass_check---------------------------------------------------------------
##plot( ctch_mdl$initialise(1e-6)$sim(mass_check=TRUE)$get_mass_errors()[,'error'] )

