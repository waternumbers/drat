library(testthat)
library(FKF)

test_check("FKF")
