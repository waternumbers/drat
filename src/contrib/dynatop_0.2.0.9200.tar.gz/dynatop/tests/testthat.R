library(testthat)
library(dynatop)

test_check("dynatop")
