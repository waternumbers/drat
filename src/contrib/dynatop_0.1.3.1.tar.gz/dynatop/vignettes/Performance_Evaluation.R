## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo=FALSE, results='asis'----------------------------------------------
factors <- data.frame(Factor = c("The number of time steps to be evaluated",
                                 "The number of input series",
                                 "The number of hill slope HRU",
                                 "The number of channel HRU",
                                 "The number of computational steps"),
                      Value = c(1000000,1000,5000,1000,3000000),
                      Comment = c("Approximately 30 years of 15 minute data",
                                  "Enough to allow for some representation of spatial input",
                                  "Approximately 10 hill slope units for each spatial input",
                                  "Enough to output 1000km of river in 1km lengths for a hydraulic model",
                                  "Approximately running 30 years of 15 minute data with 3 sub steps (5 minute step)"),
                      stringsAsFactors=FALSE)
knitr::kable(factors,caption="Factor affecting performance and limits considered")

## ---- echo=FALSE, results='asis'----------------------------------------------
mem_usage<- data.frame(Usage= c("Storage of input data",
                                "Storage of output data",
                                "Storage of hill slope states & parameters",
                                "Storage of channel states"),
                       Value = c(factors[1,'Value']*(factors[2,'Value']+1),
                                factors[1,'Value']*(factors[4,'Value']+1) + factors[3,'Value']*30,
                                factors[3,'Value']*30 + 2*(factors[3,'Value']^2),
                                factors[4,'Value']*6 + 2*(factors[3,'Value']+factors[4,'Value'])),
                       stringsAsFactors=FALSE)
mem_usage[,'Value'] <- signif(mem_usage[,'Value']*8/1e6,1)
knitr::kable(mem_usage,caption="Approximate memory usage in MB assuming a 8 bit numeric values")

## ---- load_data---------------------------------------------------------------
library(dynatop)
data("performance_record")

