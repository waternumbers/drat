## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
                    collapse = TRUE,
                    comment = "#>"
                  )

## ----echo=FALSE---------------------------------------------------------------
## devtools::load_all("/home/paul/Documents/Software/dynamic_topmodel/dynatopGIS")
library("dynatopGIS")
library("raster")

## ---- data--------------------------------------------------------------------
M <- matrix(1:100,10,10)
dem <- raster::raster(M,
                      crs="+init=epsg:27700") # UK OS projection
chn <- rasterToPolygons(dem,function(x){x==1})
chn$length <- 10
chn$startNode <- "node1"
chn$endNode <- "node2"
chn$width <- 0.001

## ---- example1----------------------------------------------------------------
ex1_dem <- dem
ex1_dem[c(23:26,33:36,44:45)] <- NA

ex1_dir <- tempfile("ex1")
dir.create(ex1_dir)
ex1 <- dynatopGIS$new(file.path(ex1_dir,"meta.json"))
ex1$add_dem(ex1_dem)
ex1$add_channel(chn)
ex1$compute_areas()
ex1$sink_fill()
ex1$plot_layer("dem",FALSE)
ex1$plot_layer("filled_dem",FALSE)
unlink(ex1_dir, recursive=TRUE)

## ---- example2----------------------------------------------------------------
ex2_dem <- dem
ex2_dem[c(23:26,33:36,44:45)] <- NA
ex2_dir <- tempfile("ex2")
dir.create(ex2_dir)
ex2 <- dynatopGIS$new(file.path(ex2_dir,"meta.json"))
ex2$add_dem(ex2_dem)
ex2$add_channel(chn)
ex2$compute_areas()
ex2$sink_fill()
ex2$plot_layer("dem",FALSE)
ex2$plot_layer("filled_dem",FALSE)
unlink(ex2_dir, recursive=TRUE)

