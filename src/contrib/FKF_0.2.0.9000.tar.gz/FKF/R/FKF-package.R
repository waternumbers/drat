#' @useDynLib FKF
#' @import graphics
# #' @import RUnit
#' @importFrom grDevices rainbow
#' @importFrom stats acf ccf ppoints qchisq qnorm qqnorm qqplot
#' @exportClass fkf
NULL
##export("fkf", "plot.fkf")
##exportClasses("fkf")
## export plot method for class fkf
##S3method("plot", "fkf")

