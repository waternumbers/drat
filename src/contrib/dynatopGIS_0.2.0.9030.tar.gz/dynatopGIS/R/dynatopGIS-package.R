#' dynatopGIS
#'
#' This package contains the code for setting up a dynamic TOPMODEL implimentation
#'
#' @name dynatopGIS
#' @docType package
#' @import raster
#' @importFrom methods is 
NULL
