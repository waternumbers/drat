#' wmts
#'
#' This package contains the a slippy map tile generator for R
#'
#' @name wmts
#' @docType package
NULL
