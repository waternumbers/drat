## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- setup-------------------------------------------------------------------
library(wmts)
outdir <- tempfile()
fn <- system.file("extdata","glofas.nc",package="wmts",mustWork=TRUE)

## ---- therest-----------------------------------------------------------------
brk <- c(-Inf,0.000000e+00,2.656250e-01,2.453125e+00,2.239063e+05,Inf)
crp <- colorRampPalette(c("lightblue", "blue"),alpha=TRUE)
pal <- genPalette(brk,crp)

genTiles(fn,pal,outdir)

plotPalette(pal,file.path(outdir,"legend.svg"))

## ---- tidy_up-----------------------------------------------------------------
unlink(outdir)

