# wnts 0.0.0.9002

- Improved tile generation speed by switching to using `terra` package
- Seperated out function for generating a single time


# wmts 0.0.0.9000

## New Features

- Function to define a colour palette
- Function to generate a legend for the colour palette
- Function to generate tiles from a raster layer and colour palette

## Breaking changes

- None

## Significant Regressions

- None
