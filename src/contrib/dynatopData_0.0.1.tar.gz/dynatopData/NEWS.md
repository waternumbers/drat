# dynatopData 0.1

Initial version. 

# Context

This package is the result of splitting the dynatopGIS package to make it more acceptable to CRAN.

This package contains the data used for the vignettes in the dynatopGIS package which may be useful for people experimenting with that package for the first time.

# New features

- Contains the DEM and Channel network for the Swindale catchment.

