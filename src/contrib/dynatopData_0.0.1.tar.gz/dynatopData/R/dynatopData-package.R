#' dynatopData
#'
#' This package contains the example data in various formats for the dynatopGIS package examples
#'
#' @name dynatopData
#' @docType package
NULL
