## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
                    collapse = TRUE,
                    comment = "#>"
                  )


## ----eval=FALSE---------------------------------------------------------------
#  my_new_object  <-  my_object

## ----eval=FALSE---------------------------------------------------------------
#  my_new_object  <-  my_object$clone()

## ----load_library-------------------------------------------------------------
library("dynatopGIS")

## ---- initialization----------------------------------------------------------
dem_file <- system.file("extdata", "SwindaleDTM4mFilled.tif", package="dynatopData", mustWork = TRUE)
channel_file <- system.file("extdata", "SwindaleRiverNetwork.shp", package="dynatopData", mustWork = TRUE)

## ---- create_brick------------------------------------------------------------
dem <- raster::raster(dem_file)
ctch <- dynatopGIS$new(dem)

## ---- channel_current---------------------------------------------------------
sp_lines <- rgdal::readOGR(channel_file)
head(sp_lines)

## ---- channel_properties------------------------------------------------------
property_names <- c(channel_id="identifier",
                    endNode="endNode",
                    startNode="startNode",
                    length="length")

## ---- add_channel-------------------------------------------------------------
ctch$add_channel(sp_lines,property_names)

## ---- list_layers-------------------------------------------------------------
ctch$get_layer()

## ---- plot--------------------------------------------------------------------
ctch$plot_layer("dem")

## ---- get_layer---------------------------------------------------------------
ctch$get_layer("dem")

## ---- sink_fill---------------------------------------------------------------
ctch$sink_fill()

raster::plot( ctch$get_layer('filled_dem') - ctch$get_layer('dem'),
             main="Changes to height")

## ---- calc_atb----------------------------------------------------------------
ctch$compute_properties()

## plot of topographic index (log(a/tan b))
ctch$plot_layer('atanb')

## plot of order of pixels (1 highest)
ctch$plot_layer('band')

## ----height layer-------------------------------------------------------------
tmp <- raster::reclassify( ctch$get_layer("filled_dem"), #RasterLayer
                          matrix(c(0,500,NA,
                                   500,1000,-999),
                                   byrow=TRUE))
ctch$add_layer(tmp,'greater_500') ## add the layer to ctch

## ---- atb_500_split-----------------------------------------------------------
ctch$classify(cuts=list(atanb=20),burns="greater_500")

## ----get_class_all------------------------------------------------------------
ctch$get_class()

## ----plot_class---------------------------------------------------------------
ctch$plot_class()

## ---- model_atb_split---------------------------------------------------------
ctch$classify(cuts=list(atanb=20))
ctch$create_model(band=5)

## ----plot_model---------------------------------------------------------------
ctch$plot_model()

